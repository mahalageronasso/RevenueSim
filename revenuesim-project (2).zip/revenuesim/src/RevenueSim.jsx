import React, { useState, useMemo } from "react";
import {
  ResponsiveContainer, ComposedChart, Line, Area, XAxis, YAxis,
  CartesianGrid, Tooltip, ReferenceLine, ReferenceDot,
} from "recharts";

// ════════════════════════════════════════════════════════════════════════════
// REVENUESIM — Hotel revenue-management decision simulator
// Sister app to ForecastLab. Jumeirah Beach Hotel Dubai · 599 rooms.
// Engine is deterministic and transparent so the maths can be taught.
// ════════════════════════════════════════════════════════════════════════════

const ROOMS = 599;
const VAR_COST = 180; // AED variable cost per occupied room

// palette (shared with ForecastLab)
const C = {
  ink: "#23211c", paper: "#f4f0e6", panel: "#fbf8f0", line: "#ddd5c2",
  gold: "#b8863b", goldDk: "#8c6325", teal: "#2f6d6a", rust: "#a8542e",
  muted: "#7d7768", green: "#5b7a4a", blue: "#7a9bb0", sand: "#f0e7d2",
};
const SERIF = "'Spectral', Georgia, serif";
const MONO = "'DM Mono', monospace";

// ── DEMAND ENGINE ────────────────────────────────────────────────────────────
// Q = qBase · (price/pRef)^elasticity · (price/comp)^compSens   (capped at ROOMS)
function runEngine(price, sc) {
  const { pRef, qBase, elasticity, comp, compSens = -0.6 } = sc;
  let demand = qBase * Math.pow(price / pRef, elasticity) * Math.pow(price / comp, compSens);
  const sold = Math.min(demand, ROOMS);
  const occ = sold / ROOMS;
  const revenue = sold * price;
  const revpar = revenue / ROOMS;
  const gop = sold * (price - VAR_COST);
  const goppar = gop / ROOMS;
  const parity = price / comp;
  return { sold: Math.round(sold), occ, revenue, revpar, goppar, parity, price };
}

// ── COMPOSITE SCORE (0–100): RevPAR 50 · margin 30 · parity discipline 20 ──────
function scoreResult(r, sc) {
  const t = sc.revparTarget;
  const revparPts = Math.max(0, Math.min(50, (r.revpar / t) * 45));
  const marginPts = Math.max(0, Math.min(30, (r.goppar / (t * 0.78)) * 30));
  let parityPts;
  if (r.parity >= 0.97) parityPts = 20;
  else if (r.parity >= 0.9) parityPts = 14;
  else if (r.parity >= 0.82) parityPts = 7;
  else parityPts = 2;
  const total = Math.round(revparPts + marginPts + parityPts);
  return { total, revparPts: Math.round(revparPts), marginPts: Math.round(marginPts), parityPts };
}

// best achievable score across the price range (for grading + feedback)
function optimum(sc) {
  let best = { total: -1 };
  for (let p = sc.min; p <= sc.max; p += 5) {
    const s = scoreResult(runEngine(p, sc), sc);
    if (s.total > best.total) best = { ...s, price: p };
  }
  return best;
}

// ── SUBMISSION CODEC (same FLAB format as ForecastLab) ────────────────────────
const INSTRUCTOR_PASSWORD = "REVENUE26"; // change before sharing with students
function encodeSubmission(obj) {
  const json = JSON.stringify(obj);
  const b64 = btoa(unescape(encodeURIComponent(json)));
  let sum = 0;
  for (let i = 0; i < b64.length; i++) sum = (sum + b64.charCodeAt(i) * (i + 1)) % 9973;
  const tag = sum.toString(36).padStart(3, "0").toUpperCase();
  const body = b64.replace(/(.{5})/g, "$1 ").trim();
  return `FLAB-${tag}::${body}`;
}
function decodeSubmission(code) {
  try {
    const m = code.trim().match(/^FLAB-([0-9A-Z]{3})::([\s\S]+)$/);
    if (!m) return { ok: false, err: "Not a valid FLAB code (missing header)." };
    const tag = m[1];
    const b64 = m[2].replace(/\s+/g, "");
    let sum = 0;
    for (let i = 0; i < b64.length; i++) sum = (sum + b64.charCodeAt(i) * (i + 1)) % 9973;
    const calc = sum.toString(36).padStart(3, "0").toUpperCase();
    const tampered = calc !== tag;
    const json = decodeURIComponent(escape(atob(b64)));
    return { ok: true, data: JSON.parse(json), tampered };
  } catch (e) {
    return { ok: false, err: "Could not decode — the code may be incomplete or corrupted." };
  }
}

// ── SCENARIO LIBRARY — 5 cases, calibrated to comparable peak scores ──────────
const SCENARIOS = [
  {
    id: "heatwave", title: "The August Heat Wave", season: "Low season",
    brief: "It's mid-August. A heat advisory has kept leisure demand soft, and your comp set just dropped to AED 1,180 to chase occupancy. You're 12% behind your monthly RevPAR budget. The GM wants the number defended — not a fire sale.",
    pRef: 1230, qBase: 380, elasticity: -1.3, comp: 1180, compSens: -0.6,
    revparTarget: 780, min: 900, max: 1500, start: 1230,
    coach: "Chasing occupancy by undercutting the comp set tanks both margin and parity. Hold close to the comp price and protect RevPAR.",
  },
  {
    id: "f1peak", title: "The F1 December Peak", season: "Peak season",
    brief: "Grand Prix weekend. The city is packed, demand is surging, and guests are far less price-sensitive than usual. Your comp set sits at AED 1,950. This is the night to capture rate — but price too high and you'll still leave rooms empty.",
    pRef: 2050, qBase: 560, elasticity: -0.7, comp: 1950, compSens: -0.45,
    revparTarget: 1700, min: 1500, max: 2600, start: 2050,
    coach: "Demand is strong and inelastic — this is when you push rate. A premium over the comp set is justified, as long as you don't price yourself into empty rooms.",
  },
  {
    id: "gitex", title: "The GITEX Congress", season: "High season",
    brief: "GITEX has filled Dubai with business travellers on expense accounts. Demand is compressed and relatively inelastic, but the comp set is disciplined at AED 1,520. Corporate guests will pay — within reason.",
    pRef: 1580, qBase: 540, elasticity: -0.6, comp: 1520, compSens: -0.5,
    revparTarget: 1300, min: 1200, max: 2100, start: 1580,
    coach: "Compression and inelastic corporate demand mean you can hold a firm rate. Stay near the comp set and let high occupancy do the work.",
  },
  {
    id: "pricewar", title: "The Comp Set Price War", season: "Shoulder season",
    brief: "A nearby competitor slashed rates to AED 1,150 and the rest of the comp set is following. Demand is elastic and guests are shopping hard on price. Match the cut and you bleed margin; ignore it and you bleed occupancy.",
    pRef: 1350, qBase: 420, elasticity: -1.1, comp: 1150, compSens: -0.85,
    revparTarget: 820, min: 850, max: 1700, start: 1350,
    coach: "A price war is a trap. Matching every cut destroys margin. Stay disciplined near the comp set — a small premium often beats a race to the bottom.",
  },
  {
    id: "shoulder", title: "The Shoulder Weekend", season: "Shoulder season",
    brief: "An ordinary October weekend. Demand is moderate, the comp set is steady at AED 1,450, and there's no special event to lean on. This is the bread-and-butter call revenue managers make most often.",
    pRef: 1480, qBase: 440, elasticity: -1.0, comp: 1450, compSens: -0.6,
    revparTarget: 980, min: 1000, max: 1900, start: 1480,
    coach: "No event, balanced demand. The disciplined move is to hold rate close to the comp set and optimise RevPAR — neither greedy nor desperate.",
  },
];

// ── UI PRIMITIVES ─────────────────────────────────────────────────────────────
const fmtAED = (x) => "AED " + Math.round(x).toLocaleString();
const fmtPct = (x) => (x * 100).toFixed(1) + "%";

function Gauge({ label, value, max, color, unit, hint }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 5 }}>
        <span style={{ fontSize: 12.5, color: C.muted, fontFamily: MONO, letterSpacing: 0.5 }}>{label}</span>
        <span style={{ fontSize: 15, fontWeight: 700, color, fontFamily: MONO }}>{unit === "aed" ? fmtAED(value) : unit === "pct" ? fmtPct(value) : value.toFixed(2)}</span>
      </div>
      <div style={{ height: 7, background: "#ece4d2", borderRadius: 4, overflow: "hidden" }}>
        <div style={{ width: pct + "%", height: "100%", background: color, transition: "width .5s cubic-bezier(.4,0,.2,1)" }} />
      </div>
      {hint && <div style={{ fontSize: 10.5, color: C.muted, marginTop: 3, fontStyle: "italic" }}>{hint}</div>}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
export default function RevenueSim() {
  const [stage, setStage] = useState("entry"); // entry | play | instructor
  const [diff, setDiff] = useState("bba");
  const [group, setGroup] = useState("");
  const [scIdx, setScIdx] = useState(0);
  const sc = SCENARIOS[scIdx];

  const [price, setPrice] = useState(sc.start);
  const [committed, setCommitted] = useState(null);
  const [code, setCode] = useState("");

  const live = useMemo(() => runEngine(price, sc), [price, sc]);
  const liveScore = useMemo(() => scoreResult(live, sc), [live, sc]);
  const opt = useMemo(() => optimum(sc), [sc]);
  const grade = committed ? Math.round((committed.score.total / opt.total) * 100) : null;

  const startScenario = (i) => { setScIdx(i); setPrice(SCENARIOS[i].start); setCommitted(null); setCode(""); setStage("play"); };
  const commit = () => setCommitted({ price, result: live, score: liveScore });
  const retry = () => { setCommitted(null); setPrice(sc.start); setCode(""); };

  // ── generate FLAB submission code ──
  const generateCode = () => {
    if (!committed) return;
    const payload = {
      v: 1, app: "RevenueSim", group: group.trim() || "Unnamed team",
      scenario: sc.title, scenarioId: sc.id, diff,
      price: committed.price, grade,
      score: committed.score.total, best: opt.total,
      revpar: Math.round(committed.result.revpar), occ: +(committed.result.occ * 100).toFixed(1),
      parts: committed.score, ts: new Date().toISOString(),
    };
    setCode(encodeSubmission(payload));
  };

  return (
    <div style={{ background: C.paper, minHeight: "100vh", fontFamily: SERIF, color: C.ink }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Spectral:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400&family=DM+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; }
        input[type=range] { accent-color: ${C.gold}; }
        @keyframes rise { from { opacity:0; transform:translateY(10px);} to {opacity:1;transform:none;} }
        @keyframes pop { 0%{transform:scale(.9);opacity:0;} 60%{transform:scale(1.03);} 100%{transform:scale(1);opacity:1;} }
      `}</style>

      {/* HEADER */}
      <header style={{ background: C.ink, borderBottom: `3px solid ${C.gold}` }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "20px 28px", display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 14 }}>
          <div>
            <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: 2.5, color: C.gold, textTransform: "uppercase" }}>RDM 2301 &amp; MHM 7223 · The Revenue Manager's Chair</div>
            <h1 style={{ margin: "4px 0 2px", fontSize: 32, fontWeight: 800, color: C.paper, letterSpacing: -0.5 }}>
              Revenue<span style={{ color: C.gold }}>Sim</span>
            </h1>
            <div style={{ fontSize: 13.5, color: "#c9c0a8", fontStyle: "italic" }}>Make the call. Live with the consequences. · Jumeirah Beach Hotel Dubai · 599 rooms</div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button onClick={() => setStage("instructor")} style={{ border: `1px solid ${C.gold}`, background: "transparent", color: C.gold, cursor: "pointer", padding: "8px 14px", borderRadius: 8, fontFamily: SERIF, fontSize: 13, fontWeight: 600 }}>★ Instructor</button>
            <div style={{ display: "flex", gap: 6, background: "#1a1814", padding: 5, borderRadius: 10 }}>
              {[["bba", "BBA"], ["msc", "MSc"]].map(([k, lbl]) => (
                <button key={k} onClick={() => setDiff(k)} style={{ border: "none", cursor: "pointer", padding: "7px 14px", borderRadius: 7, fontFamily: SERIF, fontSize: 13, fontWeight: 600, background: diff === k ? C.gold : "transparent", color: diff === k ? C.ink : C.muted, transition: "all .15s" }}>{lbl}</button>
              ))}
            </div>
          </div>
        </div>
      </header>

      <main style={{ maxWidth: 1180, margin: "0 auto", padding: "24px 28px 60px" }}>
        {stage === "entry" && <EntryScreen group={group} setGroup={setGroup} onStart={startScenario} />}
        {stage === "instructor" && <InstructorScreen onBack={() => setStage(committed ? "play" : "entry")} />}
        {stage === "play" && (
          <PlayScreen sc={sc} diff={diff} price={price} setPrice={setPrice} live={live} liveScore={liveScore}
            committed={committed} commit={commit} retry={retry} grade={grade} opt={opt}
            group={group} onGenerate={generateCode} code={code}
            onChangeScenario={() => setStage("entry")} />
        )}
        <footer style={{ textAlign: "center", marginTop: 36, fontSize: 11.5, color: C.muted, fontFamily: MONO }}>
          RevenueSim · companion to ForecastLab · paste your code into Moodle to submit
        </footer>
      </main>
    </div>
  );
}

// ── ENTRY SCREEN ──────────────────────────────────────────────────────────────
function EntryScreen({ group, setGroup, onStart }) {
  return (
    <div style={{ animation: "rise .4s ease both", maxWidth: 880, margin: "0 auto" }}>
      <div style={{ textAlign: "center", marginBottom: 26 }}>
        <h2 style={{ fontSize: 26, fontWeight: 800, margin: "8px 0 6px" }}>Take the Revenue Manager's chair</h2>
        <p style={{ fontSize: 15, color: "#4a463d", maxWidth: 560, margin: "0 auto", lineHeight: 1.55 }}>
          Name your team, pick a scenario, and make the pricing call. When you commit, you'll get a submission code to paste into Moodle — graded on how well you played your scenario.
        </p>
      </div>
      <div style={{ maxWidth: 460, margin: "0 auto 26px" }}>
        <label style={{ fontSize: 12.5, fontWeight: 600, fontFamily: MONO, color: C.muted, letterSpacing: 0.5 }}>YOUR TEAM NAME</label>
        <input value={group} onChange={(e) => setGroup(e.target.value)} placeholder="e.g. Team RevPAR"
          style={{ width: "100%", marginTop: 6, padding: "12px 15px", border: `1.5px solid ${C.line}`, borderRadius: 9, fontSize: 16, fontFamily: SERIF, background: C.panel, color: C.ink, outline: "none" }} />
      </div>
      <div style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: 2, color: C.gold, textTransform: "uppercase", textAlign: "center", marginBottom: 14 }}>Choose your scenario</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 13 }}>
        {SCENARIOS.map((s, i) => (
          <button key={s.id} onClick={() => { if (!group.trim()) { alert("Enter a team name first."); return; } onStart(i); }}
            style={{ textAlign: "left", cursor: "pointer", background: C.panel, border: `1px solid ${C.line}`, borderLeft: `4px solid ${C.gold}`, borderRadius: 11, padding: "16px 18px", transition: "transform .12s, box-shadow .12s" }}
            onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 6px 18px rgba(35,33,28,0.12)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "none"; }}>
            <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: 1.5, color: C.rust, textTransform: "uppercase", marginBottom: 5 }}>{s.season}</div>
            <div style={{ fontSize: 17, fontWeight: 800, marginBottom: 6 }}>{s.title}</div>
            <div style={{ fontSize: 12.5, color: "#4a463d", lineHeight: 1.45 }}>{s.brief.slice(0, 95)}…</div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ── INSTRUCTOR SCREEN — password gate + decode FLAB codes ─────────────────────
function InstructorScreen({ onBack }) {
  const [authed, setAuthed] = useState(false);
  const [pw, setPw] = useState("");
  const [raw, setRaw] = useState("");
  const [decoded, setDecoded] = useState(null);

  if (!authed) {
    return (
      <div style={{ animation: "rise .4s ease both", maxWidth: 420, margin: "40px auto", textAlign: "center" }}>
        <div style={{ fontSize: 34, marginBottom: 8 }}>🔒</div>
        <h2 style={{ fontSize: 22, fontWeight: 800, margin: "0 0 6px" }}>Instructor Access</h2>
        <p style={{ fontSize: 13.5, color: C.muted, margin: "0 0 18px" }}>Decode and review student submission codes. Students should not open this.</p>
        <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password"
          onKeyDown={(e) => e.key === "Enter" && pw === INSTRUCTOR_PASSWORD && setAuthed(true)}
          style={{ width: "100%", padding: "11px 14px", border: `1.5px solid ${C.line}`, borderRadius: 9, fontSize: 15, fontFamily: SERIF, background: C.panel, color: C.ink, outline: "none", textAlign: "center", marginBottom: 12 }} />
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={onBack} style={{ flex: 1, background: "transparent", color: C.muted, border: `1px solid ${C.line}`, borderRadius: 9, padding: "11px", fontSize: 14, fontWeight: 600, cursor: "pointer", fontFamily: SERIF }}>← Back</button>
          <button onClick={() => pw === INSTRUCTOR_PASSWORD ? setAuthed(true) : alert("Wrong password")} style={{ flex: 2, background: C.ink, color: C.paper, border: "none", borderRadius: 9, padding: "11px", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: SERIF }}>Unlock</button>
        </div>
      </div>
    );
  }

  const decode = () => setDecoded(decodeSubmission(raw));
  const d = decoded?.data;

  return (
    <div style={{ animation: "rise .4s ease both", maxWidth: 720, margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ fontSize: 24, fontWeight: 800, margin: 0 }}>★ Decode Submission</h2>
        <button onClick={onBack} style={{ border: "none", background: C.ink, color: C.paper, cursor: "pointer", padding: "8px 16px", borderRadius: 8, fontFamily: SERIF, fontSize: 13, fontWeight: 600 }}>← Back</button>
      </div>
      <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 5, fontFamily: MONO, color: C.muted }}>PASTE A TEAM'S CODE</div>
      <textarea value={raw} onChange={(e) => setRaw(e.target.value)} rows={3} placeholder="FLAB-XXX::..."
        style={{ width: "100%", padding: "11px 14px", border: `1.5px solid ${C.line}`, borderRadius: 9, fontSize: 12, fontFamily: MONO, background: C.panel, color: C.ink, outline: "none" }} />
      <button onClick={decode} style={{ marginTop: 10, background: C.ink, color: C.paper, border: "none", borderRadius: 9, padding: "10px 20px", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: SERIF }}>Decode →</button>

      {decoded?.err && <div style={{ marginTop: 14, background: "#f6e3dc", color: C.rust, borderRadius: 10, padding: "12px 15px", fontSize: 13.5 }}>⚠ {decoded.err}</div>}

      {d && (
        <div style={{ marginTop: 18 }}>
          {decoded.tampered && <div style={{ background: "#f6e3dc", color: C.rust, borderRadius: 10, padding: "10px 14px", fontSize: 13, marginBottom: 14 }}>⚠ Checksum mismatch — this code may have been hand-edited.</div>}
          <div style={{ background: C.ink, color: C.paper, borderRadius: 13, padding: "18px 22px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 14 }}>
            <div>
              <div style={{ fontSize: 20, fontWeight: 800 }}>{d.group}</div>
              <div style={{ fontFamily: MONO, fontSize: 12, color: "#c9c0a8" }}>{d.scenario} · {d.diff === "msc" ? "MSc" : "BBA"} · {new Date(d.ts).toLocaleString()}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 34, fontWeight: 800, fontFamily: MONO, color: C.gold, lineHeight: 1 }}>{d.grade}%</div>
              <div style={{ fontSize: 11, color: "#c9c0a8", fontFamily: MONO }}>vs optimal</div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(120px,1fr))", gap: 10, marginTop: 14 }}>
            {[["Rate set", fmtAED(d.price)], ["RevPAR", fmtAED(d.revpar)], ["Occupancy", d.occ + "%"], ["Composite", d.score + "/" + d.best]].map(([k, v]) => (
              <div key={k} style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 10, padding: "12px 14px" }}>
                <div style={{ fontSize: 11, color: C.muted, marginBottom: 4 }}>{k}</div>
                <div style={{ fontFamily: MONO, fontSize: 16, fontWeight: 700, color: C.goldDk }}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 12, fontFamily: MONO, fontSize: 12.5, color: C.muted }}>
            Score breakdown — RevPAR {d.parts.revparPts}/50 · Margin {d.parts.marginPts}/30 · Parity {d.parts.parityPts}/20
          </div>
        </div>
      )}
    </div>
  );
}

// ── PLAY SCREEN ───────────────────────────────────────────────────────────────
function PlayScreen({ sc, diff, price, setPrice, live, liveScore, committed, commit, retry, grade, opt, group, onGenerate, code, onChangeScenario }) {
  return (
    <div>
      {/* SCENARIO BRIEF */}
      <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderLeft: `4px solid ${C.rust}`, borderRadius: 12, padding: "18px 22px", marginBottom: 22, animation: "rise .4s ease both" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: 8 }}>
          <div style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: 2, color: C.rust, textTransform: "uppercase" }}>{sc.season} · Team {group || "—"}</div>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <span style={{ fontFamily: MONO, fontSize: 11, color: C.muted }}>Comp: {fmtAED(sc.comp)} · Target RevPAR: {fmtAED(sc.revparTarget)}</span>
            <button onClick={onChangeScenario} style={{ border: `1px solid ${C.line}`, background: "transparent", color: C.muted, cursor: "pointer", padding: "5px 11px", borderRadius: 7, fontFamily: SERIF, fontSize: 12 }}>Change</button>
          </div>
        </div>
        <h2 style={{ fontSize: 23, fontWeight: 800, margin: "5px 0 8px" }}>{sc.title}</h2>
        <p style={{ fontSize: 14.5, lineHeight: 1.6, color: "#4a463d", margin: 0, maxWidth: 760 }}>{sc.brief}</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, alignItems: "start" }}>
        {/* LEFT: decision */}
        <div style={{ animation: "rise .45s ease both" }}>
          <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 14, padding: "22px 24px" }}>
            <div style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: 2, color: C.gold, textTransform: "uppercase", marginBottom: 16 }}>◆ Your decision — set tonight's rate</div>
            <div style={{ textAlign: "center", marginBottom: 6 }}>
              <div style={{ fontSize: 44, fontWeight: 800, fontFamily: MONO, color: C.goldDk, lineHeight: 1 }}>{fmtAED(price)}</div>
              <div style={{ fontSize: 12, color: C.muted, marginTop: 4 }}>average daily rate (ADR)</div>
            </div>
            <input type="range" min={sc.min} max={sc.max} step={5} value={price}
              onChange={(e) => { setPrice(parseInt(e.target.value)); }} disabled={!!committed}
              style={{ width: "100%", margin: "14px 0 4px", cursor: committed ? "not-allowed" : "pointer" }} />
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: C.muted, fontFamily: MONO }}>
              <span>{fmtAED(sc.min)}</span><span>comp {fmtAED(sc.comp)}</span><span>{fmtAED(sc.max)}</span>
            </div>
            <div style={{ marginTop: 16, padding: "10px 14px", borderRadius: 9, fontSize: 13, fontFamily: MONO, textAlign: "center",
              background: live.parity >= 0.9 ? "#e7f0e3" : "#f6e3dc", color: live.parity >= 0.9 ? C.green : C.rust }}>
              {live.parity >= 0.97 ? "✓ At parity with comp set" : live.parity >= 0.9 ? "↓ Slightly below comp" : live.parity < 0.82 ? "⚠ Deep discount — brand & margin at risk" : "↓ Discounting below comp"}
              {"  ·  "}{(live.parity * 100).toFixed(0)}% of comp
            </div>
            {!committed ? (
              <button onClick={commit} style={{ width: "100%", marginTop: 18, background: C.ink, color: C.paper, border: "none", borderRadius: 10, padding: "14px", fontSize: 15, fontWeight: 700, fontFamily: SERIF, cursor: "pointer", letterSpacing: 0.3 }}>Commit this rate →</button>
            ) : (
              <button onClick={retry} style={{ width: "100%", marginTop: 18, background: "transparent", color: C.ink, border: `1.5px solid ${C.line}`, borderRadius: 10, padding: "13px", fontSize: 14, fontWeight: 600, fontFamily: SERIF, cursor: "pointer" }}>↺ Try a different rate</button>
            )}
          </div>
          {diff === "bba" && !committed && (
            <div style={{ marginTop: 14, display: "flex", gap: 12, background: C.sand, border: `1px solid ${C.line}`, borderRadius: 11, padding: "13px 16px" }}>
              <span style={{ fontSize: 18 }}>💡</span>
              <p style={{ margin: 0, fontSize: 13, lineHeight: 1.5, color: "#5a513c", fontStyle: "italic" }}>{sc.coach}</p>
            </div>
          )}
        </div>

        {/* RIGHT: consequences */}
        <div style={{ animation: "rise .5s ease both" }}>
          <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 14, padding: "22px 24px" }}>
            <div style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: 2, color: C.teal, textTransform: "uppercase", marginBottom: 16 }}>◆ Projected outcome</div>
            <Gauge label="Occupancy" value={live.occ} max={1} color={C.blue} unit="pct" hint={`${live.sold} of ${ROOMS} rooms sold`} />
            <Gauge label="RevPAR" value={live.revpar} max={sc.revparTarget * 1.3} color={C.gold} unit="aed" hint={`target ${fmtAED(sc.revparTarget)}`} />
            <Gauge label="GOPPAR (margin)" value={live.goppar} max={sc.revparTarget} color={C.green} unit="aed" hint={`after AED ${VAR_COST} variable cost/room`} />
            <div style={{ borderTop: `1px dashed ${C.line}`, marginTop: 8, paddingTop: 14, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 13, color: C.muted, fontFamily: MONO }}>Total revenue tonight</span>
              <span style={{ fontSize: 20, fontWeight: 800, fontFamily: MONO, color: C.ink }}>{fmtAED(live.revenue)}</span>
            </div>
            {diff === "msc" && (
              <div style={{ marginTop: 14, padding: "12px 16px", background: C.ink, borderRadius: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: 12, color: "#c9c0a8", fontFamily: MONO }}>Composite score (live)</span>
                <span style={{ fontSize: 22, fontWeight: 800, fontFamily: MONO, color: C.gold }}>{liveScore.total}<span style={{ fontSize: 13, color: C.muted }}>/100</span></span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* DEMAND CURVE */}
      <div style={{ background: C.panel, border: `1px solid ${C.line}`, borderRadius: 14, padding: "20px 18px 14px", marginTop: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4, paddingLeft: 6 }}>How price drives RevPAR &amp; occupancy</div>
        <div style={{ fontSize: 12, color: C.muted, paddingLeft: 6, marginBottom: 8, fontStyle: "italic" }}>The gold dot is your current rate. RevPAR peaks before occupancy does — that gap is where revenue management lives.</div>
        <DemandChart sc={sc} price={price} live={live} />
      </div>

      {/* RESULT after commit */}
      {committed && (
        <div style={{ marginTop: 22, background: C.ink, borderRadius: 16, padding: "26px 28px", animation: "pop .45s ease both" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 18 }}>
            <div style={{ flex: "1 1 320px" }}>
              <div style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: 2, color: C.gold, textTransform: "uppercase" }}>Decision committed · {fmtAED(committed.price)}</div>
              <div style={{ fontSize: 26, fontWeight: 800, color: C.paper, margin: "6px 0 14px" }}>
                {grade >= 92 ? "Textbook revenue management." : grade >= 75 ? "Solid call, with room to sharpen." : grade >= 55 ? "Defensible, but you left money on the table." : "The GM won't love this one."}
              </div>
              <ResultFeedback committed={committed} opt={opt} sc={sc} />
              {!code ? (
                <button onClick={onGenerate} style={{ marginTop: 8, background: C.gold, color: C.ink, border: "none", borderRadius: 10, padding: "12px 22px", fontSize: 14.5, fontWeight: 700, fontFamily: SERIF, cursor: "pointer" }}>
                  Generate submission code →
                </button>
              ) : (
                <div style={{ marginTop: 12 }}>
                  <div style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: 1.5, color: C.gold, textTransform: "uppercase", marginBottom: 6 }}>✓ Your code — paste into Moodle</div>
                  <textarea readOnly value={code} rows={4} onFocus={(e) => e.target.select()}
                    style={{ width: "100%", padding: "10px 13px", border: `2px solid ${C.gold}`, borderRadius: 9, fontSize: 11.5, fontFamily: MONO, background: "#1a1814", color: "#ddd5c2", outline: "none", wordBreak: "break-all", resize: "vertical" }} />
                </div>
              )}
            </div>
            <div style={{ textAlign: "center", minWidth: 160 }}>
              <div style={{ fontSize: 12, color: "#c9c0a8", fontFamily: MONO, marginBottom: 4 }}>Performance vs optimal</div>
              <div style={{ fontSize: 58, fontWeight: 800, fontFamily: MONO, color: grade >= 75 ? C.gold : grade >= 55 ? "#d8a24a" : C.rust, lineHeight: 1 }}>{grade}%</div>
              <div style={{ fontSize: 11.5, color: C.muted, fontFamily: MONO, marginTop: 6 }}>your {committed.score.total} · best {opt.total}</div>
              <div style={{ marginTop: 14, fontSize: 11, color: "#c9c0a8", fontFamily: MONO, lineHeight: 1.6, textAlign: "left", background: "#1a1814", borderRadius: 8, padding: "10px 12px" }}>
                RevPAR&nbsp;&nbsp;{committed.score.revparPts}/50<br />Margin&nbsp;&nbsp;&nbsp;{committed.score.marginPts}/30<br />Parity&nbsp;&nbsp;&nbsp;{committed.score.parityPts}/20
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── DEMAND CHART (extracted) ──────────────────────────────────────────────────
function DemandChart({ sc, price, live }) {
  const curve = useMemo(() => {
    const out = [];
    for (let p = sc.min; p <= sc.max; p += 25) {
      const r = runEngine(p, sc);
      out.push({ price: p, RevPAR: Math.round(r.revpar), Occupancy: Math.round(r.occ * 100) });
    }
    return out;
  }, [sc]);
  return (
    <ResponsiveContainer width="100%" height={280}>
      <ComposedChart data={curve} margin={{ top: 8, right: 14, left: -4, bottom: 4 }}>
        <CartesianGrid strokeDasharray="2 4" stroke={C.line} vertical={false} />
        <XAxis dataKey="price" tick={{ fontSize: 10.5, fill: C.muted, fontFamily: "DM Mono" }} tickFormatter={(v) => v.toLocaleString()} />
        <YAxis yAxisId="l" tick={{ fontSize: 10.5, fill: C.muted, fontFamily: "DM Mono" }} />
        <YAxis yAxisId="r" orientation="right" domain={[0, 100]} unit="%" tick={{ fontSize: 10.5, fill: C.muted, fontFamily: "DM Mono" }} />
        <Tooltip contentStyle={{ background: "#fdfbf5", border: `2px solid ${C.gold}`, borderRadius: 9, fontFamily: "DM Mono", fontSize: 12, boxShadow: "0 4px 14px rgba(35,33,28,0.18)" }}
          itemStyle={{ fontWeight: 600 }} labelStyle={{ color: C.goldDk, fontWeight: 700, marginBottom: 3 }} labelFormatter={(v) => "ADR " + Number(v).toLocaleString()} />
        <Area yAxisId="r" type="monotone" dataKey="Occupancy" stroke={C.blue} fill="rgba(122,155,176,0.14)" strokeWidth={1.5} />
        <Line yAxisId="l" type="monotone" dataKey="RevPAR" stroke={C.gold} strokeWidth={2.6} dot={false} />
        <ReferenceLine yAxisId="l" x={Math.round(price / 25) * 25} stroke={C.goldDk} strokeDasharray="4 3" />
        <ReferenceDot yAxisId="l" x={Math.round(price / 25) * 25} y={Math.round(live.revpar)} r={6} fill={C.gold} stroke={C.ink} strokeWidth={1.5} />
      </ComposedChart>
    </ResponsiveContainer>
  );
}

// ── narrative feedback after commit ───────────────────────────────────────────
function ResultFeedback({ committed, opt, sc }) {
  const r = committed.result;
  const lines = [];
  lines.push(`You sold ${r.sold} rooms at ${fmtPct(r.occ)} occupancy, for ${fmtAED(r.revenue)} in revenue and a RevPAR of ${fmtAED(r.revpar)} (target ${fmtAED(sc.revparTarget)}).`);
  if (r.parity < 0.82) lines.push("By cutting well below the comp set you filled rooms, but margin and rate parity both suffered — exactly the fire sale the GM warned against.");
  else if (r.parity > 1.12) lines.push("You held a strong premium over the comp set. That protects rate, but the empty rooms cost you RevPAR you can't get back.");
  else lines.push("You kept rate close to the comp set — the disciplined zone where RevPAR and margin both hold up.");
  const gap = opt.price - committed.price;
  if (Math.abs(gap) <= 20) lines.push(`Your rate sat right around the revenue-optimal point (~${fmtAED(opt.price)}). Hard to do better here.`);
  else if (gap > 0) lines.push(`The model's best score came a little higher, near ${fmtAED(opt.price)} — there was headroom to hold rate without losing many more rooms.`);
  else lines.push(`The model's best score came a little lower, near ${fmtAED(opt.price)} — a touch more occupancy would have lifted RevPAR.`);
  return (
    <div>
      {lines.map((l, i) => (
        <p key={i} style={{ margin: "0 0 9px", fontSize: 13.5, lineHeight: 1.55, color: "#ddd5c2" }}>{l}</p>
      ))}
    </div>
  );
}
